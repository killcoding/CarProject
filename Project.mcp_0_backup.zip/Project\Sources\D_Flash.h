
#ifndef _D_FLASH_H
#define _D_FLASH_H



extern void  DFlash_Init(void);
extern word  DFlash_Read (word destination);

extern void  DFlash_Erase(word ADDR16);

#endif